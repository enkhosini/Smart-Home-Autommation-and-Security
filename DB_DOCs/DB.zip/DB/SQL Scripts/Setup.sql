INSERT INTO users (username, passwrd, email) VALUES
('sobonga', 'sobonga123', '240254260@edu.vut.ac.za'),
('fanelo', 'fanelo123', '224303635@edu.vut.ac.za'),
('maambele', 'maambele123', '240716574@edu.vut.ac.za'),
('bridgette', 'bridgette123', '@edu.vut.ac.za'),
('muzi', 'muzi123', '221569766@edu.vut.ac.za');